import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  // 환경변수 VITE_ANTHROPIC_API_KEY 를 클라이언트에 노출
  // 로컬 개발용 — 배포 시 서버사이드 프록시로 교체 예정
});
