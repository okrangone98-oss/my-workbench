# 출근 전 10분 수익 루틴

Claude AI 기반 5단계 콘텐츠 자동화 툴

## 설치 및 실행 (로컬)

### 1. 의존성 설치
```bash
npm install
```

### 2. API 키 설정
`.env.example`을 복사해서 `.env` 파일 생성 후 키 입력:
```bash
cp .env.example .env
```
`.env` 파일 열어서 API 키 입력:
```
VITE_ANTHROPIC_API_KEY=sk-ant-여기에_본인_키_입력
```
> API 키 발급: https://console.anthropic.com

### 3. 개발 서버 실행
```bash
npm run dev
```
브라우저에서 `http://localhost:5173` 접속

---

## 프로젝트 구조

```
morning-routine/
├── src/
│   ├── main.jsx     # React 진입점
│   ├── App.jsx      # 메인 UI
│   └── api.js       # Claude API 호출 모듈
├── index.html
├── vite.config.js
├── .env             # API 키 (깃헙에 올리면 안 됨!)
├── .env.example     # API 키 템플릿 (깃헙에 올려도 됨)
└── .gitignore       # .env 제외 설정 포함
```

---

## GitHub 업로드

```bash
git init
git add .
git commit -m "init: 출근 전 10분 수익 루틴"
git remote add origin https://github.com/본인계정/morning-routine.git
git push -u origin main
```

> ⚠ `.env` 파일은 `.gitignore`에 포함되어 있어 자동으로 제외됩니다.

---

## 배포 (Vercel 권장)

1. [vercel.com](https://vercel.com) 에서 GitHub 레포 연결
2. 환경변수 설정: `VITE_ANTHROPIC_API_KEY` 입력
3. Deploy 클릭

> ⚠ **보안 주의**: 현재 구조는 API 키가 브라우저에 노출됩니다.
> 공개 배포 전에 Next.js Route Handler 또는 Vercel Edge Function으로
> API 호출을 서버사이드로 이동시켜야 합니다.

---

## 5단계 기능

| 단계 | 기능 | 산출물 |
|------|------|--------|
| 1 | 트렌드 수집 | 글로벌 트렌드 5개 + 조회수 포인트 |
| 2 | 썸네일 카피 | 10만뷰 카피 3세트 |
| 3 | 대본 초안 | 60초 숏폼 타임코드 대본 |
| 4 | 편집 지시서 | CapCut/Vrew 편집 세팅 |
| 5 | 업로드 준비 | 제목·해시태그·설명란·최적시간 |
