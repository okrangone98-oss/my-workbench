// Claude API 호출 유틸
// 로컬: .env 파일의 VITE_ANTHROPIC_API_KEY 사용
// 배포 후: 서버사이드 Route Handler 로 교체 예정

const API_KEY = import.meta.env.VITE_ANTHROPIC_API_KEY;

export async function callClaude(systemPrompt, userPrompt) {
  if (!API_KEY) {
    throw new Error(
      "API 키가 없습니다. 프로젝트 루트에 .env 파일을 만들고\nVITE_ANTHROPIC_API_KEY=sk-ant-xxx 를 입력하세요."
    );
  }

  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": API_KEY,
      "anthropic-version": "2023-06-01",
      // 로컬 개발 시 CORS 우회용 헤더
      "anthropic-dangerous-direct-browser-access": "true",
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      system: systemPrompt,
      messages: [{ role: "user", content: userPrompt }],
    }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err?.error?.message ?? `API 오류: ${res.status}`);
  }

  const data = await res.json();
  return data.content?.find((b) => b.type === "text")?.text ?? "";
}
