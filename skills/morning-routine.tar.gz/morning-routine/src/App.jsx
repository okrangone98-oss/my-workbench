import { useState, useEffect, useRef } from "react";
import { callClaude } from "./api.js";

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const STEPS = [
  { id: 1, label: "트렌드 수집",  emoji: "🌐", color: "#00e5ff" },
  { id: 2, label: "썸네일 카피",  emoji: "⚡", color: "#ff6b35" },
  { id: 3, label: "대본 초안",    emoji: "📝", color: "#a8ff3e" },
  { id: 4, label: "편집 지시서",  emoji: "🎬", color: "#ff3de8" },
  { id: 5, label: "업로드 준비",  emoji: "🚀", color: "#ffd700" },
];

export default function App() {
  const [topic,       setTopic]       = useState("");
  const [running,     setRunning]     = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [results,     setResults]     = useState({});
  const [done,        setDone]        = useState(false);
  const [activeView,  setActiveView]  = useState(null);
  const [progress,    setProgress]    = useState(0);
  const [copied,      setCopied]      = useState(null);
  const [error,       setError]       = useState("");
  const inputRef = useRef(null);

  useEffect(() => { inputRef.current?.focus(); }, []);

  const reset = () => {
    setTopic(""); setRunning(false); setCurrentStep(0);
    setResults({}); setDone(false); setActiveView(null);
    setProgress(0); setCopied(null); setError("");
    setTimeout(() => inputRef.current?.focus(), 100);
  };

  const run = async () => {
    if (!topic.trim()) return;
    setRunning(true); setDone(false); setResults({});
    setCurrentStep(1); setProgress(0); setError("");

    const r = {};

    try {
      // ── STEP 1 트렌드 수집
      setCurrentStep(1); setProgress(10);
      r[1] = await callClaude(
        "당신은 글로벌 트렌드 분석 전문가입니다. 반드시 한국어로 답변하세요.",
        `주제: "${topic}"\n\n이 주제와 관련해 유튜브·소셜미디어에서 지금 뜨는 트렌드 5가지를 분석해줘.\n각 트렌드: ① 트렌드 이름 ② 왜 뜨는지 한 줄 ③ 조회수 포인트`
      );
      setResults({ ...r }); setProgress(25); await sleep(200);

      // ── STEP 2 썸네일 카피
      setCurrentStep(2); setProgress(35);
      r[2] = await callClaude(
        "당신은 유튜브 썸네일 카피라이팅 전문가입니다. 반드시 한국어로 답변하세요.",
        `주제: "${topic}"\n트렌드: ${r[1].slice(0, 300)}\n\n조회수 10만을 넘길 썸네일 카피 3개.\n각 카피: ① 메인 문구(15자 이내) ② 서브 문구(10자 이내) ③ 클릭 심리 포인트`
      );
      setResults({ ...r }); setProgress(50); await sleep(200);

      // ── STEP 3 대본 초안
      setCurrentStep(3); setProgress(58);
      r[3] = await callClaude(
        "당신은 유튜브 숏폼 대본 전문가입니다. 반드시 한국어로 답변하세요.",
        `주제: "${topic}"\n썸네일: ${r[2].slice(0, 200)}\n\n60초 숏폼 대본.\n[훅 3초] → [문제 제기 10초] → [핵심 3포인트 35초] → [CTA 12초]\n타임코드와 실제 멘트 포함.`
      );
      setResults({ ...r }); setProgress(72); await sleep(200);

      // ── STEP 4 편집 지시서
      setCurrentStep(4); setProgress(82);
      r[4] = await callClaude(
        "당신은 영상 편집 디렉터입니다. CapCut/Vrew 편집 지시서를 작성합니다. 반드시 한국어로 답변하세요.",
        `주제: "${topic}"\n대본 요약: ${r[3].slice(0, 400)}\n\n편집 지시서:\n① 배경음악 분위기\n② 자막 스타일(폰트·색상·크기)\n③ 컷 타이밍 가이드\n④ 효과음 포인트\n⑤ 인트로/아웃트로`
      );
      setResults({ ...r }); setProgress(92); await sleep(200);

      // ── STEP 5 업로드 준비
      setCurrentStep(5); setProgress(97);
      r[5] = await callClaude(
        "당신은 유튜브 SEO 전문가입니다. 반드시 한국어로 답변하세요.",
        `주제: "${topic}"\n썸네일: ${r[2].slice(0, 200)}\n\n업로드 패키지:\n① 제목 3가지(SEO 최적화, 50자 이내)\n② 설명란 첫 3줄\n③ 해시태그 10개\n④ 최적 업로드 시간대\n⑤ 커뮤니티 포스팅 문구`
      );
      setResults({ ...r }); setProgress(100);

      setCurrentStep(0); setDone(true); setActiveView(1);
    } catch (e) {
      setError(e.message);
    } finally {
      setRunning(false);
    }
  };

  const copyText = (text, id) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };

  // ── 스타일 상수
  const S = {
    page: {
      minHeight: "100vh", background: "#060810",
      fontFamily: "'DM Mono','Courier New',monospace",
      color: "#e8e8f0", overflowX: "hidden",
    },
    grid: {
      position: "fixed", inset: 0, zIndex: 0, pointerEvents: "none",
      backgroundImage: `linear-gradient(rgba(0,229,255,0.04) 1px,transparent 1px),
        linear-gradient(90deg,rgba(0,229,255,0.04) 1px,transparent 1px)`,
      backgroundSize: "40px 40px",
    },
    header: {
      position: "relative", zIndex: 10,
      borderBottom: "1px solid rgba(0,229,255,0.15)",
      padding: "20px 32px",
      display: "flex", alignItems: "center", justifyContent: "space-between",
      background: "rgba(6,8,16,0.8)", backdropFilter: "blur(12px)",
    },
    main: {
      position: "relative", zIndex: 5,
      maxWidth: "900px", margin: "0 auto", padding: "40px 24px",
    },
  };

  return (
    <div style={S.page}>
      <div style={S.grid} />

      {/* 헤더 */}
      <header style={S.header}>
        <div>
          <div style={{ fontSize: "11px", color: "#00e5ff", letterSpacing: "4px", marginBottom: "4px" }}>
            CONTENT AUTOMATION SYSTEM
          </div>
          <div style={{ fontSize: "22px", fontWeight: "700" }}>출근 전 10분 수익 루틴</div>
        </div>
        {done && (
          <button onClick={reset} style={{
            background: "transparent", border: "1px solid rgba(0,229,255,0.4)",
            color: "#00e5ff", padding: "8px 20px", fontSize: "12px",
            letterSpacing: "2px", cursor: "pointer", fontFamily: "inherit",
          }}>
            RESET
          </button>
        )}
      </header>

      <main style={S.main}>

        {/* 에러 */}
        {error && (
          <div style={{
            border: "1px solid rgba(255,80,80,0.5)", background: "rgba(255,80,80,0.07)",
            padding: "16px 20px", marginBottom: "24px", color: "#ff8080",
            fontSize: "13px", whiteSpace: "pre-wrap",
          }}>
            ⚠ {error}
          </div>
        )}

        {/* ── 입력 화면 */}
        {!running && !done && (
          <div style={{ marginBottom: "48px" }}>
            <div style={{ fontSize: "13px", color: "#888", letterSpacing: "3px", marginBottom: "16px" }}>
              오늘의 콘텐츠 주제를 입력하세요
            </div>
            <div style={{ display: "flex", gap: "12px" }}>
              <input
                ref={inputRef}
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && run()}
                placeholder="예: AI로 돈 버는 법, 양양 서핑 입문, 귀촌 6년 후기..."
                style={{
                  flex: 1, background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(0,229,255,0.3)", color: "#e8e8f0",
                  padding: "16px 20px", fontSize: "16px",
                  outline: "none", fontFamily: "inherit",
                }}
              />
              <button
                onClick={run}
                disabled={!topic.trim()}
                style={{
                  background: topic.trim() ? "#00e5ff" : "rgba(0,229,255,0.2)",
                  border: "none",
                  color: topic.trim() ? "#060810" : "#555",
                  padding: "16px 32px", fontSize: "14px",
                  fontWeight: "700", letterSpacing: "2px",
                  cursor: topic.trim() ? "pointer" : "not-allowed",
                  fontFamily: "inherit",
                }}
              >
                START →
              </button>
            </div>

            {/* 단계 미리보기 */}
            <div style={{
              marginTop: "40px", display: "grid",
              gridTemplateColumns: "repeat(5, 1fr)", gap: "12px",
            }}>
              {STEPS.map((s) => (
                <div key={s.id} style={{
                  border: "1px solid rgba(255,255,255,0.08)",
                  padding: "16px 12px", textAlign: "center",
                  background: "rgba(255,255,255,0.02)",
                }}>
                  <div style={{ fontSize: "24px", marginBottom: "8px" }}>{s.emoji}</div>
                  <div style={{ fontSize: "10px", color: "#888", letterSpacing: "1px" }}>STEP {s.id}</div>
                  <div style={{ fontSize: "12px", marginTop: "4px", color: s.color }}>{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── 실행 중 */}
        {running && (
          <div style={{ marginBottom: "48px" }}>
            {/* 프로그레스 바 */}
            <div style={{ background: "rgba(255,255,255,0.05)", height: "3px", marginBottom: "40px", position: "relative" }}>
              <div style={{
                position: "absolute", top: 0, left: 0, height: "100%",
                width: `${progress}%`,
                background: "linear-gradient(90deg,#00e5ff,#a8ff3e)",
                transition: "width 0.5s ease",
                boxShadow: "0 0 12px rgba(0,229,255,0.6)",
              }} />
            </div>

            {STEPS.map((s) => {
              const isActive = currentStep === s.id;
              const isDone   = !!results[s.id];
              return (
                <div key={s.id} style={{
                  display: "flex", alignItems: "center", gap: "16px",
                  padding: "16px 20px", marginBottom: "12px",
                  border: `1px solid ${isActive ? s.color : isDone ? "rgba(168,255,62,0.3)" : "rgba(255,255,255,0.06)"}`,
                  background: isActive ? "rgba(0,0,0,0.4)" : "transparent",
                  transition: "all 0.3s",
                }}>
                  <div style={{
                    width: "36px", height: "36px", flexShrink: 0,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    border: `1px solid ${isActive ? s.color : isDone ? "#a8ff3e" : "rgba(255,255,255,0.1)"}`,
                    fontSize: "16px",
                    color: isActive ? s.color : isDone ? "#a8ff3e" : "#555",
                  }}>
                    {isDone ? "✓" : s.emoji}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: "11px", letterSpacing: "1px", color: isActive ? s.color : isDone ? "#a8ff3e" : "#555" }}>
                      {isDone ? `STEP ${s.id} 완료` : isActive ? `STEP ${s.id} 처리 중...` : `STEP ${s.id} 대기`}
                    </div>
                    <div style={{ fontSize: "15px", marginTop: "2px", color: isActive ? "#e8e8f0" : isDone ? "#aaa" : "#444" }}>
                      {s.label}
                    </div>
                  </div>
                  {isActive && (
                    <div style={{ display: "flex", gap: "4px" }}>
                      {[0, 1, 2].map((i) => (
                        <div key={i} style={{
                          width: "5px", height: "5px", borderRadius: "50%",
                          background: s.color,
                          animation: `pulse 1s ease-in-out ${i * 0.2}s infinite`,
                        }} />
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* ── 결과 화면 */}
        {done && (
          <div>
            <div style={{
              border: "1px solid rgba(168,255,62,0.4)",
              background: "rgba(168,255,62,0.05)",
              padding: "20px 24px", marginBottom: "32px",
              display: "flex", alignItems: "center", gap: "16px",
            }}>
              <div style={{ fontSize: "28px" }}>✅</div>
              <div>
                <div style={{ color: "#a8ff3e", fontSize: "13px", letterSpacing: "3px" }}>COMPLETE</div>
                <div style={{ fontSize: "16px", marginTop: "2px" }}>
                  <strong>"{topic}"</strong> 콘텐츠 자동화 완료
                </div>
              </div>
            </div>

            {/* 탭 */}
            <div style={{ display: "flex", borderBottom: "1px solid rgba(255,255,255,0.1)", marginBottom: "24px" }}>
              {STEPS.map((s) => (
                <button key={s.id} onClick={() => setActiveView(s.id)} style={{
                  background: activeView === s.id ? "rgba(255,255,255,0.06)" : "transparent",
                  border: "none",
                  borderBottom: activeView === s.id ? `2px solid ${s.color}` : "2px solid transparent",
                  color: activeView === s.id ? s.color : "#555",
                  padding: "12px 16px", fontSize: "12px",
                  letterSpacing: "1px", cursor: "pointer",
                  fontFamily: "inherit", whiteSpace: "nowrap",
                }}>
                  {s.emoji} {s.label}
                </button>
              ))}
            </div>

            {activeView && results[activeView] && (
              <div style={{
                background: "rgba(255,255,255,0.03)",
                border: "1px solid rgba(0,229,255,0.15)",
                padding: "28px", position: "relative",
              }}>
                <button onClick={() => copyText(results[activeView], activeView)} style={{
                  position: "absolute", top: "16px", right: "16px",
                  background: copied === activeView ? "rgba(168,255,62,0.2)" : "rgba(255,255,255,0.06)",
                  border: `1px solid ${copied === activeView ? "#a8ff3e" : "rgba(255,255,255,0.15)"}`,
                  color: copied === activeView ? "#a8ff3e" : "#888",
                  padding: "6px 16px", fontSize: "11px", letterSpacing: "2px",
                  cursor: "pointer", fontFamily: "inherit",
                }}>
                  {copied === activeView ? "COPIED ✓" : "COPY"}
                </button>
                <pre style={{
                  whiteSpace: "pre-wrap", wordBreak: "break-word",
                  fontSize: "14px", lineHeight: "1.8", color: "#d8d8e8",
                  fontFamily: "inherit", margin: 0, paddingRight: "80px",
                }}>
                  {results[activeView]}
                </pre>
              </div>
            )}
          </div>
        )}

      </main>

      <style>{`
        @keyframes pulse {
          0%,100%{transform:scale(1);opacity:.6}
          50%{transform:scale(1.4);opacity:1}
        }
        *{box-sizing:border-box}
        input::placeholder{color:#444}
        ::-webkit-scrollbar{width:4px}
        ::-webkit-scrollbar-thumb{background:rgba(0,229,255,.3)}
      `}</style>
    </div>
  );
}
